#include "stdafx.h"

int
__cdecl
wmain()
{
    fwprintf(stdout, L"%s\n", L"This is an output sent to stdout.");
    return 0;
}
