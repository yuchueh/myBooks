//
// Windows Headers
//
#include <tchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

//
// ATL Smart Pointers and string
//
#include <atlbase.h>
#include <atlstr.h>

//
// Common Implementation Headers
//
#include "corelib.h"

